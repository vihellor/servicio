#!/bin/bash
echo $1
echo $2
shift 3
echo $1
echo $2
