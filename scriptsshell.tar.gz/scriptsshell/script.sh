#!/bin/bash
cd /etc
ls -l
echo $0
echo $*
echo $?
echo $#
