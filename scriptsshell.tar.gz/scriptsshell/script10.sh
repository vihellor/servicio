#!/bin/bash

c=1
while [ $c -ne 5 ]; do
	read c
done

echo "nos vemos mañana"